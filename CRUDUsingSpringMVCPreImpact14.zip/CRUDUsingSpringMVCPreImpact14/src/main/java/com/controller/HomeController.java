package com.controller;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.dao.JavaConfigurationClass;
import com.dao.ProductDaoImpl;
import com.model.Product;

@Controller
public class HomeController {
	static ApplicationContext context = new AnnotationConfigApplicationContext(JavaConfigurationClass.class);
	static ProductDaoImpl pDao = context.getBean("pDao", ProductDaoImpl.class);
	@RequestMapping("/home")
	public String getHome() {
		return "home";
	}
	
	@RequestMapping("/addProduct")
	public String addProduct() {
		return "addProduct";
	}
	
	@RequestMapping("/added")
	public String insertProduct(@RequestParam("pid") int pid,
			@RequestParam("pname")String pname,@RequestParam("pprice") float pprice) {
		Product prod = new Product();
		prod.setPid(pid);
		prod.setPname(pname);
		prod.setPprice(pprice);
		pDao.insert(prod);
		return "successMessage";
	}
	
	@RequestMapping("/update")
	public String updateProduct() {
		return "updateProduct";
	}
	
	@RequestMapping("/updated")
	public String updateDone(@ModelAttribute Product product) {
		System.out.println(product.getPid());
		System.out.println(product.getPname());
		System.out.println(product.getPprice());
		pDao.updateProduct(product);
		return "updated";
		
	}
	@RequestMapping("/product")
	public ModelAndView getProduct() {
		List<Product> product = pDao.getAllProducts();
		ModelAndView mv = new ModelAndView();
		mv.addObject("products",product);
		mv.setViewName("products");
		return mv;
		
		
	}

}
