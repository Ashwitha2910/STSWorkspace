package com.dao;

import org.springframework.data.repository.CrudRepository;

import com.model.Student;

public interface AdminRepository extends CrudRepository<Student, Integer>{

}
