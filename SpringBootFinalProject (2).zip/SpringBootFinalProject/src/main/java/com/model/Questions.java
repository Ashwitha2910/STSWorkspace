package com.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Questons")
public class Questions {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int qId;
	private String que;
	private String opt1;
	private String opt2;
	private String opt3;
	private String correctAns;
	
	public int getqId() {
		return qId;
	}
	public void setqId(int qId) {
		this.qId = qId;
	}
	public String getQue() {
		return que;
	}
	public void setQue(String que) {
		this.que = que;
	}
	public String getOpt1() {
		return opt1;
	}
	public void setOpt1(String opt1) {
		this.opt1 = opt1;
	}
	public String getOpt2() {
		return opt2;
	}
	public void setOpt2(String opt2) {
		this.opt2 = opt2;
	}
	public String getOpt3() {
		return opt3;
	}
	public void setOpt3(String opt3) {
		this.opt3 = opt3;
	}
	
	public String getCorrectAns() {
		return correctAns;
	}
	public void setCorrectAns(String correctAns) {
		this.correctAns = correctAns;
	}
	
	public Questions(int qId, String que, String opt1, String opt2, String opt3, String correctAns) {
		super();
		this.qId = qId;
		this.que = que;
		this.opt1 = opt1;
		this.opt2 = opt2;
		this.opt3 = opt3;
		this.correctAns = correctAns;
	}
	public Questions() {
		super();
	}
	@Override
	public String toString() {
		return "Questions [q_id=" + qId + ", que=" + que + ", opt1=" + opt1 + ", opt2=" + opt2 + ", opt3=" + opt3
				+ ", correct_ans=" + correctAns + "]";
	}
	
	
}
