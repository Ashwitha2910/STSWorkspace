package com.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.model.Student;

import jakarta.transaction.Transactional;

public interface StudentRepository extends CrudRepository<Student, Integer> {


	@Query(value = "select sname from student where sid=?",nativeQuery = true)
	public String getStudentNameById(int id);
	
	
	@Query(value="select sname from student where sage=?", nativeQuery = true)
	public String getStudentNameWhoseAgeIs(int sage);
	
	
	
}
