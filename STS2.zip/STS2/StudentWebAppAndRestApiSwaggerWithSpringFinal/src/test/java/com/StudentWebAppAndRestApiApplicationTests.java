package com;



import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.dao.StudentRepository;


@SpringBootTest
class StudentWebAppAndRestApiApplicationTests {

	@Autowired
	StudentRepository studRepo;
	
	@Test
	void IsGivenNumberIsEven(){
		int expected=2;
		int actual=2;
		assertThat(actual).isEqualTo(expected);
		
	}
	
	@Test
	void isStudentWithIdIsPresent() {
		String actualValue = studRepo.getStudentNameById(2053);
		String expectedValue ="James";
		assertThat(actualValue).isEqualTo(expectedValue);
		
	}
	
	@Test
	void isStudentPresentNameJamesAge() {
		String actVal= studRepo.getStudentNameWhoseAgeIs(19);
		String expVal ="Kevin";
		Assertions.assertEquals(actVal, expVal);
		
	}
	

}
