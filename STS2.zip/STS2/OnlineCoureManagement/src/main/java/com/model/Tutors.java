package com.model;

public class Tutors {

	private int tutorId;
	private String tutorName;
	private String course;
	private String tutorEmail;
	private String mobile;
	public int getTutorId() {
		return tutorId;
	}
	public void setTutorId(int tutorId) {
		this.tutorId = tutorId;
	}
	public String getTutorName() {
		return tutorName;
	}
	public void setTutorName(String tutorName) {
		this.tutorName = tutorName;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public String getTutorEmail() {
		return tutorEmail;
	}
	public void setTutorEmail(String tutorEmail) {
		this.tutorEmail = tutorEmail;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public Tutors(int tutorId, String tutorName, String course, String tutorEmail, String mobile) {
		super();
		this.tutorId = tutorId;
		this.tutorName = tutorName;
		this.course = course;
		this.tutorEmail = tutorEmail;
		this.mobile = mobile;
	}
	public Tutors() {
		super();
	}
	@Override
	public String toString() {
		return "Tutors [tutorId=" + tutorId + ", tutorName=" + tutorName + ", course=" + course + ", tutorEmail="
				+ tutorEmail + ", mobile=" + mobile + "]";
	}
	
	
}
