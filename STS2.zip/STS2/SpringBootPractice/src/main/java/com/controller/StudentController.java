package com.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.DAO.StudentRepository;
import com.model.Student;

@RestController
//@RestControllerAdvice
public class StudentController {

	@Autowired
	StudentRepository strepo;
	
	
	
	@PostMapping("/student")
	public Student addStudent(@RequestBody Student student) {
		Student st= new Student();
		st.setName(student.getName());
		st.setAge(student.getAge());
		st.setPhone(student.getPhone());
		st.setAddress(student.getAddress());
		strepo.save(st);
		return st;
	}
	
	@PutMapping("/student/{stId}")
	public Student updateStudent(@RequestBody Student student, @PathVariable ("stId") int stId) {
		Student st= new Student();
		Optional<Student> stud= strepo.findById(stId);
		st=stud.get();
		st.setName(student.getName());
		st.setAge(student.getAge());
		st.setPhone(student.getPhone());
		st.setAddress(student.getAddress());
		strepo.save(st);
		return st;
	}
	
	@DeleteMapping("student/{stId}")
	public Student deleteStudent(@PathVariable("stId") int stId) {
		Student st= new Student();
		st=strepo.findById(stId).get();
		strepo.deleteById(stId);
		return st;
		
	}
	
	@GetMapping("/students")
	public List<Student> getAllStudents(){
		List<Student> li= (List<Student>) strepo.findAll();
		return li;
	}
	
	@GetMapping("/student/{stId}")
	public Student getStudentById(@PathVariable ("stId") int stId) {
		Student st= new Student();
		Optional<Student> std= strepo.findById(stId);
		st=std.get();
		return st;
	}
}
