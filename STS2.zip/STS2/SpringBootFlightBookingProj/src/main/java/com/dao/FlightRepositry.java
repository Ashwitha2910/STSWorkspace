package com.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.model.Flight;

public interface FlightRepositry extends CrudRepository<Flight, Integer>{

	@Query(value="select flight_id, flight_name, source, destination, flight_date,duration, price,capacity from flight f where source=? and destination=? And flight_date=?",nativeQuery = true)
	public List<Flight> findbySourceDestDate(String source,String destination,String flight_date);
}