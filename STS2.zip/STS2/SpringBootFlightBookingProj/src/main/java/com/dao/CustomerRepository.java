package com.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import com.model.Customer;

public interface CustomerRepository extends CrudRepository<Customer, Integer>{
	
	@Query(value="select password from customer where cust_user_name=?",nativeQuery=true)
	public String findByUserName(String cust_user_name);
}
