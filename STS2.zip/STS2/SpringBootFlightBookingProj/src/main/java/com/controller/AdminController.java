package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dao.CustomerRepository;
import com.dao.FlightRepositry;
import com.model.Customer;
import com.model.Flight;

@Controller
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	FlightRepositry frepo;
	@Autowired
	CustomerRepository crepo;

	@RequestMapping("/adminHome")
	public String getHomepage(){
		return "adminHome";
	}
	
	@RequestMapping("/addflight")
	public String addFlight() {
		return "addflight";
	}
	
	@RequestMapping("/addsuccess")
	public String addFlightToDB(@ModelAttribute Flight flight, Model model) {
		Flight fly=new Flight();
		fly.setFlightName(flight.getFlightName());
		fly.setFlightDate(flight.getFlightDate());
		fly.setSource(flight.getSource());
		fly.setDestination(flight.getDestination());
		fly.setPrice(flight.getPrice());
		fly.setDuration(flight.getDuration());
		fly.setCapacity(flight.getCapacity());
		frepo.save(fly);
		System.out.println("Flight added");
		model.addAttribute("flight", flight);
		return "addsuccess";
	}
	
	@RequestMapping("/updateflight")
	public String updateFlight() {
		return "updateflight";
	}
	
	@RequestMapping("/updatesuccess")
	public String updateInDB(@ModelAttribute Flight flight,Model model) {
		Flight fly=new Flight();
		Optional<Flight> flt=frepo.findById(flight.getFlightId());
		fly=flt.get();
		fly.setFlightName(flight.getFlightName());
		fly.setFlightDate(flight.getFlightDate());
		fly.setSource(flight.getSource());
		fly.setDestination(flight.getDestination());
		fly.setPrice(flight.getPrice());
		fly.setDuration(flight.getDuration());
		fly.setCapacity(flight.getCapacity());
		frepo.save(fly);
		System.out.println("Flight details updated");
		model.addAttribute("flight1",flight);
		return "updatesuccess";
	}
	
	@RequestMapping("/deleteflight")
	public String deleteFlight() {
		return "deleteflight";
	}
	
	@RequestMapping("/deletesuccess")
	public String deleteInDb(@RequestParam ("flightId") int flightId) {
		frepo.deleteById(flightId);
		return "deletesuccess";
		}
	
	
	
	@RequestMapping("/getflights")
	public String getAllFlights(Model model) {
		List<Flight> li=(List<Flight>)frepo.findAll();
		model.addAttribute("flights",li);
		return "getflights";
	}
	
	@RequestMapping("/getcustomer")
	public String getCustomer(Model model) {
		List<Customer> cust=(List<Customer>) crepo.findAll();
		model.addAttribute("customer", cust);
		return "getcustomer";
	}
}
