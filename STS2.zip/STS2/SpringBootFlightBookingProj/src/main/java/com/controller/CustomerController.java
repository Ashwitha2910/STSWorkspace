package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dao.BookingRepository;
import com.dao.CustomerRepository;
import com.dao.FlightRepositry;
import com.model.BookingDetails;
import com.model.Customer;
import com.model.Flight;

@Controller
@RequestMapping("/cust")
public class CustomerController {
	
	@Autowired
	CustomerRepository crepo;
	
	@Autowired
	BookingRepository brepo;
	
	@Autowired
	FlightRepositry frepo;

	@RequestMapping("/custhome")
	public String getCustHome() {
		return "custhome";
	}
	
	@RequestMapping("/register")
	public String getRegisterPage() {
		return "register";
	}
	
	@RequestMapping("/registered")
	public String addCustomer(@ModelAttribute Customer customer, Model model) {
		Customer cust=new Customer();
		cust.setCustName(customer.getCustName());
		cust.setCustUserName(customer.getCustUserName());
		cust.setPassword(customer.getPassword());
		cust.setEmail(customer.getEmail());
		cust.setPhone(customer.getPhone());
		crepo.save(cust);
		System.out.println("Registered Successfully");
		model.addAttribute("customer",customer);
		return "registered";
	}
	
	@RequestMapping("/loggedin")
	public String loggedin(@ModelAttribute Customer customer) {
		String pwd=customer.getPassword();
		String un=customer.getCustUserName();
		String pw=crepo.findByUserName(un);
		System.out.println(pw);
		System.out.println(pwd);
		if(pwd.equalsIgnoreCase(pw)) {
			return "loggedin";
		}

		else {
			return "errorpage";
		}
	}
	
	@RequestMapping("/resetpwd")
	public String resetPasword() {
		return "resetpwd";
	}
	
	@RequestMapping("/resetsuccess")
	public String resetpwInDB(@ModelAttribute Customer customer) {
		Customer cust=new Customer();
		Optional<Customer> c=crepo.findById(customer.getCustId());
		cust=c.get();
		cust.setPassword(customer.getPassword());
		crepo.save(cust);
		System.out.println(cust.getPassword());
		return "custhome";
	}
	
	@RequestMapping("/updatecust")
	public String updateCustomer() {
		return "updatecust";
	}

	@RequestMapping("/updatecustsuccess")
	public String updateCustomerinDb(@ModelAttribute Customer customer, Model model) {
		Customer cust=new Customer();
		Optional<Customer> c=crepo.findById(customer.getCustId());
		cust=c.get();
		cust.setCustName(customer.getCustName());
		cust.setCustUserName(customer.getCustUserName());
		cust.setPassword(customer.getPassword());
		cust.setEmail(customer.getEmail());
		cust.setPhone(customer.getPhone());
		crepo.save(cust);
		model.addAttribute("cust1", customer);
		return "updatecustsuccess";
	}
	
	@RequestMapping("/deletecust")
	public String deleteacc() {
		return "deletecust";
	}
	
	@RequestMapping("/deletionsuccess")
	public String deleteCustAccount(@ModelAttribute Customer customer) {
		
	 	String pwd= crepo.findByUserName(customer.getCustUserName());
		String pw=customer.getPassword();
		if(pwd.equals(pw))
		{
			return "deletionsuccess";
		}
		else
			return "errorpage";
	}
	
	@RequestMapping("/bookflight")
	public String bookTicket() {
		return "bookticket";
	}
	
	@RequestMapping("/selectflight")
	public String selectflight(@ModelAttribute Flight flight,Model model) {
		List<Flight> fly=(List<Flight>) frepo.findbySourceDestDate(flight.getSource(), flight.getDestination(), flight.getFlightDate());
		model.addAttribute("flights",fly);
		return "selectflight";
	}
	
	
	@RequestMapping("/bookingdone")
	public String TicketBookInDB(@ModelAttribute BookingDetails booking ) {
		
		return "bookingdone";
	}
}
