package com.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="Booking_Details")
public class BookingDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int bookingId;
	@OneToOne
	@JoinColumn(referencedColumnName = "custId")
	private Customer custId;
	@OneToOne
	@JoinColumn(referencedColumnName = "flightId")
	private Flight flightId;
	private float bookingAmt;
	private int seatNo;
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public Customer getCustId() {
		return custId;
	}
	public void setCustId(Customer custId) {
		this.custId = custId;
	}
	public Flight getFlightId() {
		return flightId;
	}
	public void setFlightId(Flight flightId) {
		this.flightId = flightId;
	}
	public float getBookingAmt() {
		return bookingAmt;
	}
	public void setBookingAmt(float bookingAmt) {
		this.bookingAmt = bookingAmt;
	}
	public int getSeatNo() {
		return seatNo;
	}
	public void setSeatNo(int seatNo) {
		this.seatNo = seatNo;
	}
	public BookingDetails(int bookingId, Customer custId, Flight flightId, float bookingAmt, int seatNo) {
		super();
		this.bookingId = bookingId;
		this.custId = custId;
		this.flightId = flightId;
		this.bookingAmt = bookingAmt;
		this.seatNo = seatNo;
	}
	public BookingDetails() {
		super();
	}
	
	
}
