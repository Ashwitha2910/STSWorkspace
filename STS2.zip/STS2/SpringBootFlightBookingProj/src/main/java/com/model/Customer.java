package com.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Customer")
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int custId;
	private String custName;
	private String custUserName;
	private String password;
	private String email;
	private int phone;
	
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustUserName() {
		return custUserName;
	}
	public void setCustUserName(String custUserName) {
		this.custUserName = custUserName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getPhone() {
		return phone;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	public Customer(int custId, String custName, String custUserName, String password, String email, int phone) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.custUserName = custUserName;
		this.password = password;
		this.email = email;
		this.phone = phone;
	}
	
	public Customer() {
		super();
	}
	@Override
	public String toString() {
		return "Name=" + custName + ", UserName=" + custUserName
				 + ", Email=" + email + ", Phone=" + phone;
	}
	
	

}
