package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dao.AdminRepository;
import com.dao.QuestionRepository;
import com.model.Questions;
import com.model.Student;

@Controller
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	AdminRepository adRepo;
	@Autowired
	QuestionRepository qRepo;
		
	@RequestMapping("/home")
	public String getHomePage()
	{
		return "home";
	}
	
	@RequestMapping("/addstudent")
	public String addStudent() {
		return "addstudent";

	}
	
	@RequestMapping("/addedsuccess")
	public String addStudentInDb(@ModelAttribute Student student, Model model) {
		Student stud = new Student();
		stud.setFname(student.getFname());
		stud.setLname(student.getLname());
		stud.setGender(student.getGender());
		stud.setAddress(student.getAddress());
		stud.setEmail(student.getEmail());
		adRepo.save(stud);
		System.out.println("Added ");
		model.addAttribute("student", student);
		return "addedsuccess";

	}
	
	@RequestMapping("/updatestudent")
	public String updateStudent() {
		return "updatestudent";
	}
	
	@RequestMapping("/updateindb")
	public String updateInDb(@ModelAttribute Student student) {
		Student s = new Student();
		Optional<Student> std = adRepo.findById(student.getStId());
		s = std.get();
		s.setFname(student.getFname());
		s.setLname(student.getLname());
		s.setGender(student.getGender());
		s.setAddress(student.getAddress());
		s.setEmail(student.getEmail());
		adRepo.save(s);
		return "updatesuccess";

	}
	
	@RequestMapping("/deletestudent")
	public String deleteStudent() {
		return "deletestudent";

	}
	
	@RequestMapping("/deletefromdb")
	public String deleteFromDatabase(@RequestParam("stId") int stId) {
		adRepo.deleteById(stId);
		return "deletesuccess";

	}

	@RequestMapping("/getstudents")
	public String getAllStudents(Model model) {
		List<Student> list = (List<Student>) adRepo.findAll();
		model.addAttribute("students", list);
		return "getallstudents";

	}
	
	@RequestMapping("/getstudent")
	public String getStudent() {
		return "getstudent";

	}
	@RequestMapping("/displaystudent")
	public String displayStudent(@RequestParam("stId") int id, Model model) {
		Student st = adRepo.findById(id).get();
		model.addAttribute("student",st);
		return "displaystudent";
	}
	
	//Question
	
	@RequestMapping("/addquestion")
	public String addQuestion() {
		return "addquestion";

	}
	
	@RequestMapping("/addedQsuccess")
	public String addQuestionInDb(@ModelAttribute Questions questions, Model model) {
		Questions que = new Questions();
		que.setQue(questions.getQue());
		que.setOpt1(questions.getOpt1());
		que.setOpt2(questions.getOpt2());
		que.setOpt3(questions.getOpt3());
		que.setCorrectAns(questions.getCorrectAns());
		qRepo.save(que);
		System.out.println("Added ");
		model.addAttribute("questions", questions);
		return "addedQsuccess";
	}
	
	@RequestMapping("/updatequestion")
	public String updateQuestion() {
		return "updatequestion";
	}
	
	@RequestMapping("/updateQindb")
	public String updateQuestionInDb(@ModelAttribute Questions questions) {
		Questions que = new Questions();
		Optional<Questions> std = qRepo.findById(questions.getqId());
		que = std.get();
		que.setQue(questions.getQue());
		que.setOpt1(questions.getOpt1());
		que.setOpt2(questions.getOpt2());
		que.setOpt3(questions.getOpt3());
		que.setCorrectAns(questions.getCorrectAns());
		qRepo.save(que);
		return "updatesuccess";
	}
	
	@RequestMapping("/deletequestion")
	public String deleteQuestion() {
		return "deletequestion";

	}
	
	@RequestMapping("deleteQfromdb")
	public String deleteQFromDatabase(@RequestParam("qId") int qId) {
		qRepo.deleteById(qId);
		return "deletesuccess";

	}
	
	@RequestMapping("/getQuestions")
	public String getAllQuestions(Model model) {
		List<Questions> list = (List<Questions>) qRepo.findAll();
		model.addAttribute("questions", list);
		return "getallquestions";

	}
	

}
