package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.dao.ProductRepository;
import com.model.Product;

@SpringBootApplication
public class SpringBootRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestApiApplication.class, args);
		
//		ApplicationContext	context=SpringApplication.run(SpringBootRestApiApplication.class, args);
//		
//		ProductRepository prodrepo = context.getBean(ProductRepository.class);
//		Product product = new Product();
	}

}
