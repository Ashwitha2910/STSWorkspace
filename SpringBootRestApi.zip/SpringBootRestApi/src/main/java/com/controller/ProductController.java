package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dao.ProductRepository;
import com.model.Product;

@RestController
@RequestMapping("/rest")
@CrossOrigin(origins = "http://localhost:57218")
public class ProductController {

	@Autowired
	ProductRepository prodRepo;
	
	@GetMapping("/products")
	public List<Product> getProducts(){
	 List<Product> list=(List<Product>) prodRepo.findAll();
	 System.out.println(list);
	 return list;
	}
	
	@GetMapping("/products/{pid}")
	public Product getProductById(@PathVariable("pid") int pid) {
		Product p = new Product();
		Optional<Product> prd =prodRepo.findById(pid);
		p = prd.get();
		return p;		
	}
	@PostMapping("/products")
	public Product addProduct(@RequestBody Product product) {
		Product p = new Product();
		p.setPname(product.getPname());
		p.setPprice(product.getPprice());
		prodRepo.save(p);
		return p;
	}
	
	@PutMapping("/products/{pid}")
	public Product updateProduct(@RequestBody Product product, @PathVariable("pid") int pid) {
		Product p = new Product();
		Optional<Product> prd =prodRepo.findById(pid);
		p = prd.get();
		p.setPname(product.getPname());
		p.setPprice(product.getPprice());
		return p;		
	}
	
	@DeleteMapping("/products/{pid}")
	public Product deleteProductById(@PathVariable("pid") int pid) {
		Product p = new Product();
		p= prodRepo.findById(pid).get();
		prodRepo.deleteById(pid);
		return p;		
	}
}
