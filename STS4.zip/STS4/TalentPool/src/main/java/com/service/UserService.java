package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dto.UserRequest;
import com.entity.User;
import com.exception.UserNotFoundException;
import com.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	UserRepository repo;	
	
	public User saveUser(UserRequest userRequest) {
        
		User user = new User(0, userRequest.getName(), userRequest.getEmail(),
                userRequest.getMobile(), userRequest.getGender(), userRequest.getAge(), userRequest.getNationality());
		return repo.save(user);
	}
	
	public User getUser(int id) throws UserNotFoundException {
		User user = repo.findByUserId(id);
        if(user!=null){
            return user;
        }else{
            throw new UserNotFoundException("user not found with id : "+id);
        }
	}
	
	public List<User> getAllUsers(){
		return repo.findAll();
	}
	
}
