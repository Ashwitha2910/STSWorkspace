package com.exception;

public class HttpMessageNotReadableException extends Exception{
	
	public HttpMessageNotReadableException(String message) {
		super(message);
	}

}
