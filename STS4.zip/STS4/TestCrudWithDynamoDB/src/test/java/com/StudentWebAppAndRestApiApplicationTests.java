package com;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.dao.StudentRepository;
import com.model.Student;

@SpringBootTest
class StudentWebAppAndRestApiApplicationTests {

	@Autowired
	private StudentRepository studRepo;
	
	@Test
	void contextLoads() {
	}
	
	@Test
	@DisplayName("Is Person Exists By ID true")
	@Tag("Dev")
	void isPersonExistById() {
//		Student student = new Student(1002,"Deepesh K",45,"Chennai","54321");
		Boolean actualResult = studRepo.isStudentPresentById(1003);
		assertThat(actualResult).isTrue();
//		If want to check whether not exists then use isFalse
//		assertThat(actualResult).isFalse();
	}
	
	@Test
	@DisplayName("Is Person not Exists By ID true")
	void isPersonNotExistById() {
//		Student student = new Student(1002,"Deepesh K",45,"Chennai","54321");
		Boolean actualResult = studRepo.isStudentPresentById(1005);
//		assertThat(actualResult).isTrue();
//		If want to check whether not exists then use isFalse
		assertThat(actualResult).isFalse();
	}
	
	@AfterEach
	void tearUp() {
		System.out.println("tearng down");
		studRepo.deleteAll();
	}
	
	@BeforeEach
	void setUp() {
		System.out.println("setting up");
	}

}
