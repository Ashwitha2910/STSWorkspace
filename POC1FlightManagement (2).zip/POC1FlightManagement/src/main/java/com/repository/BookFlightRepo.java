package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.model.Customer;
import com.model.Flight;
import com.model.FlightBooking;

public interface BookFlightRepo extends CrudRepository<FlightBooking, Integer>{

//	@Query(value="select ")
	public List<FlightBooking> findByCustomer(Customer custId);
	
	public List<FlightBooking> findByFlight(Flight flightId);
}
