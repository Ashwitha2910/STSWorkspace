package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.model.Flight;

public interface FlightRepo extends CrudRepository<Flight, Integer>{

	@Query(value="select flight_id, flight_name, source, destination, flight_date,duration, price,capacity from flight f where source=? and destination=? And flight_date=?",nativeQuery = true)
	public List<Flight> findBySourceDestinationAndDate(String source, String destination, String flight_date);
	
//	@Query(value="select custId from flight_booking b where flightId=(select flightId from flight f where flightId=? and flightDate=?)",nativeQuery = true)
//	public List<Flight> findByIdAndFlightDate(int flightId, String flightDate);
}
