package com.repository;

import org.springframework.data.repository.CrudRepository;

import com.model.Customer;

public interface CustomerRepo extends CrudRepository<Customer, Integer>{

	public Customer findByUsername(String username);
}
