package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.service.annotation.PutExchange;

import com.model.Customer;
import com.model.Flight;
import com.model.FlightBooking;
import com.repository.BookFlightRepo;
import com.repository.FlightRepo;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class FlightRestController {

	@Autowired
	FlightRepo frepo;
	@Autowired
	BookFlightRepo booking;
	
	@GetMapping("/flight/{source}/{destination}/{flightDate}")
	public List<Flight> getFlightsFromSourceDestAndDate(@PathVariable String source, @PathVariable String destination,@PathVariable String flightDate){
		List<Flight> list= frepo.findBySourceDestinationAndDate(source, destination, flightDate);
		return list;
	}
	
	@PostMapping("/flight")
	public Flight insertFlight( @RequestBody Flight fly) {
		Flight flight=new Flight();
		flight.setFlightName(fly.getFlightName());
		flight.setFlightDate(fly.getFlightDate());
		flight.setSource(fly.getSource());
		flight.setDestination(fly.getDestination());
		flight.setPrice(fly.getPrice());
		flight.setDuration(fly.getDuration());
		flight.setCapacity(fly.getCapacity());
		frepo.save(flight);
		return flight;
	}
	
	@PutMapping("/flight/{flightId}")
	public Flight updateFlight(@PathVariable int flightId ,@RequestBody Flight fly) {
		Flight flight=new Flight();
		Optional<Flight> f= frepo.findById(flightId);
		flight=f.get();
		flight.setFlightName(fly.getFlightName());
		flight.setFlightDate(fly.getFlightDate());
		flight.setSource(fly.getSource());
		flight.setDestination(fly.getDestination());
		flight.setPrice(fly.getPrice());
		flight.setDuration(fly.getDuration());
		flight.setCapacity(fly.getCapacity());
		frepo.save(flight);
		return flight;
	}
	
	@GetMapping("/Bookings/{custId}")
	public List<FlightBooking> getFlightBookingByCustomerId(@PathVariable Customer custId){
		List<FlightBooking> flights= booking.findByCustomer(custId);
		return flights;
	}
	
	@GetMapping("/flights")
	public List<Flight> getAllFlights(){
		List<Flight> flights=(List<Flight>) frepo.findAll();
		return flights;
	}
	
	@GetMapping("/Bookings")
	public List<FlightBooking> getAllBookings(){
		List<FlightBooking> bookings=(List<FlightBooking>) booking.findAll();
		return bookings;
	}
	
	
	
			
//	@GetMapping("customer/{flightId}/{flightDate}")
//	public List<Flight> getCustomersfromFlightIDandDate(@PathVariable int flightId, String flightDate){
//		List<Flight> customers=frepo.findByIdAndFlightDate(flightId,flightDate);
//		return customers;
//	}
}
