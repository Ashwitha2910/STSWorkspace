package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.model.Customer;
import com.model.Flight;
import com.model.FlightBooking;
import com.repository.BookFlightRepo;
import com.repository.CustomerRepo;
import com.repository.FlightRepo;

@Controller
@RequestMapping("/user")
public class CustomerController {

	@Autowired
	private CustomerRepo crepo;
	
	@Autowired
	private FlightRepo frepo;
	
	@Autowired
	private BookFlightRepo brepo;
	
	@RequestMapping("/userhome")
	public String getUserHomePage() {
		return "userhome";
	}
	
	@RequestMapping("/userBack")
	public String getUserBackPage() {
		return "main";
	}
	
	@RequestMapping("/userLogin")
	public String userLogin(@ModelAttribute Customer customer) {
		Customer cust=new Customer();
		Optional<Customer> c=crepo.findById(customer.getCustId());
		cust=c.get();
		if(cust.getUsername().equals(customer.getUsername())&& cust.getPassword().equals(customer.getPassword()))
		{
			return "main";
		}
		else
		{
			return "userhome";
		}
	}
	
	@RequestMapping("/register")
	public String getRegisterPage() {
		return "register";
	}
	
	@RequestMapping("/registered")
	public String addCustomerInDB(@ModelAttribute Customer customer, Model model) {
		Customer cust=new Customer();
		cust.setCustName(customer.getCustName());
		cust.setUsername(customer.getUsername());
		cust.setPassword(customer.getPassword());
		cust.setEmail(customer.getEmail());
		cust.setPhone(customer.getPhone());
		crepo.save(cust);
//		model.addAttribute("customer", cust);
		return "userhome";
	}
	
	@RequestMapping("/forgotpw")
	public String getpasswordChangePage() {
		return "passwordChange";
	}
	
	@RequestMapping("/resetpw")
	public String changePaswordInDb(@ModelAttribute Customer customer,Model model) {
		Customer cust=new Customer();
		cust=crepo.findByUsername(customer.getUsername());
		cust.setPassword(customer.getPassword());
		crepo.save(cust);
		model.addAttribute("customer", cust);
		return "resetsuccess";
	}
	
	@RequestMapping("/updateProfile")
	public String updateProfilePage() {
		return "updateProfile";
	}
	
	@RequestMapping("/profileUpdated")
	public String updateCustomer(@ModelAttribute Customer customer, Model model) {
		Customer cust=new Customer();
		Optional<Customer> c=crepo.findById(customer.getCustId());
		cust=c.get();
		cust.setCustName(customer.getCustName());
		cust.setUsername(customer.getUsername());
		cust.setPassword(customer.getPassword());
		cust.setEmail(customer.getEmail());
		cust.setPhone(customer.getPhone());
		crepo.save(cust);
		model.addAttribute("customer", cust);
		return "profileUpdated";
	}
	
	@RequestMapping("/deleteAccount")
	public String getDeleteAccountPage() {
		return "deleteAccount";
	}
	
	@RequestMapping("/deleteCustomer")
	public String deleteCustomerFromDB(@ModelAttribute Customer customer) {
		Customer cust=new Customer();
		Optional<Customer> c=crepo.findById(customer.getCustId());
		cust=c.get();
		if(cust.getUsername().equals(customer.getUsername())&& cust.getPassword().equals(customer.getPassword()))
		{
			return "userhome";
		}
		else
		{
			return "errorPage";
		}
	}
	@RequestMapping("/bookFlight")
	public String getSearchFlightPage() {
		return "searchFlight";
	}
	
	@RequestMapping("/selectFlight")
	public String searchFlight(@ModelAttribute Flight flight,Model model) {
	    List<Flight>list= frepo.findBySourceDestinationAndDate(flight.getSource(), flight.getDestination(), flight.getFlightDate());
		model.addAttribute("flights", list);
	    return "bookTicket";
	}
	
	@RequestMapping("/bookingdone")
	public String bookTicketInDB(@ModelAttribute FlightBooking booking, Model model) {
		FlightBooking book=new FlightBooking();
		book.setCustomer(booking.getCustomer());
		book.setFlight(booking.getFlight());
		book.setAmount(booking.getAmount());
		book.setSeatNo(booking.getSeatNo());
		brepo.save(book);
		model.addAttribute("booking", book);
		return "bookingDone";
	}
	
	@RequestMapping("/cancelBooking")
	public String getCancelTicketPage() {
		return "cancelBooking";
	}
	
	@RequestMapping("/flightCanceled")
	public String deleteBookingInDB(@ModelAttribute FlightBooking booking) {
		FlightBooking book=new FlightBooking();
		Optional<FlightBooking> f= brepo.findById(booking.getBookingId());
		book=f.get();
		if(book.getCustomer().equals(booking.getCustomer()))
		{
			brepo.deleteById(book.getBookingId());
			return "main";
		}
		else
		{
			return "errorPage";
		}
	}
	
	@RequestMapping("/bookingHistory")
	public String getBookingHistory() {
		return "gethistory";
	}
	
	@RequestMapping("/history")
	public String getHistory(@ModelAttribute FlightBooking booking,Model model) {
		List<FlightBooking>list=brepo.findByCustomer(booking.getCustomer());
		model.addAttribute("history", list);
		return "history";
	}
	
}