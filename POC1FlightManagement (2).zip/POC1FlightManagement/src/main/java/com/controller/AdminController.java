package com.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.model.Admin;
import com.model.Customer;
import com.model.Flight;
import com.repository.AdminRepo;
import com.repository.CustomerRepo;
import com.repository.FlightRepo;

@Controller
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	private AdminRepo adrepo;
	@Autowired
	private FlightRepo frepo;
	@Autowired
	private CustomerRepo crepo;

	@RequestMapping("/login")
	public String getadminLoginPage() {
		return "login";
	}
	
	@RequestMapping("/adminhome")
	public String adminHomePage(@ModelAttribute Admin admin) {
		Admin ad= new Admin();
		Optional<Admin> a= adrepo.findById(admin.getAdminId());
		ad=a.get();
		if(ad.getUn().equals(admin.getUn()) && ad.getPw().equals(admin.getPw()))
		{
			return "adminhomepage";
		}
		else 
			return "login";
	}
	
	@RequestMapping("/addFlight")
	public String addFlightPage() {
		return "addFlight";
	}
	
	@RequestMapping("/addsuccess")
	public String addFlightToDB(@ModelAttribute Flight flight, Model model) {
		Flight fly=new Flight();
		fly.setFlightName(flight.getFlightName());
		fly.setFlightDate(flight.getFlightDate());
		fly.setSource(flight.getSource());
		fly.setDestination(flight.getDestination());
		fly.setPrice(flight.getPrice());
		fly.setDuration(flight.getDuration());
		fly.setCapacity(flight.getCapacity());
		frepo.save(fly);
		model.addAttribute("flight", fly);
		return "flightadded";
	}
	
	@RequestMapping("/updateFlight")
	public String updateFlightPage() {
		return "updateFlight";
	}
	
	@RequestMapping("/updateFlightInDB")
	public String updateFlightInDB(@ModelAttribute Flight flight, Model model) {
		Flight fly=new Flight();
		Optional<Flight> f= frepo.findById(flight.getFlightId());
		fly=f.get();
		fly.setFlightName(flight.getFlightName());
		fly.setFlightDate(flight.getFlightDate());
		fly.setSource(flight.getSource());
		fly.setDestination(flight.getDestination());
		fly.setPrice(flight.getPrice());
		fly.setDuration(flight.getDuration());
		fly.setCapacity(flight.getCapacity());
		frepo.save(fly);
		model.addAttribute("flight", fly);
		return "updatesuccess";
	}
	
	@RequestMapping("/deleteFlight")
	public String deleteFlightPage() {
		return "deleteFlight";
	}
	
	@RequestMapping("/deleteFlightInDB")
	public String deleteFlightInDB(@RequestParam("flightId") int flightId,Model model) {
		Flight fly=new Flight();
		Optional<Flight> f= frepo.findById(flightId);
		fly=f.get();
		frepo.deleteById(flightId);
		model.addAttribute("flight", fly);
		return "deletesuccess";
	}
	
	@RequestMapping("/backpage")
	public String backPage() {
		return "adminhomepage";
	}
	
	@RequestMapping("/getFlightById")
	public String getFlightByIdPage() {
		return "getFlight";
	}
	
	@RequestMapping("/getFlightsuccess")
	public String getFlightById(@RequestParam("flightId") int flightId,Model model) {
		Flight fly=new Flight();
		Optional<Flight> f= frepo.findById(flightId);
		fly=f.get();
		model.addAttribute("flight", fly);
		return "flightDetail";
	}
	
	@RequestMapping("/getCustomertById")
	public String getCustomertByIdPage() {
		return "getCustomer";
	}
	
	@RequestMapping("/getCustomersuccess")
	public String getCustomerById(@RequestParam("custId") int custId,Model model) {
		Customer cust=new Customer();
		Optional<Customer> c= crepo.findById(custId);
		cust=c.get();
		model.addAttribute("customer", cust);
		return "custDetail";
	}
	
}
