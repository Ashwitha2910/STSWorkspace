package com.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Flight")
public class Flight {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int flightId;
	private String flightName;
	private String flightDate;
	private String source;
	private String destination;
	private float price;
	private float duration;
	private int capacity;
	public int getFlightId() {
		return flightId;
	}
	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	
	public String getFlightDate() {
		return flightDate;
	}
	public void setFlightDate(String flightDate) {
		this.flightDate = flightDate;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public float getDuration() {
		return duration;
	}
	public void setDuration(float duration) {
		this.duration = duration;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	
	public Flight(int flightId, String flightName, String flightDate, String source, String destination, float price,
			float duration, int capacity) {
		super();
		this.flightId = flightId;
		this.flightName = flightName;
		this.flightDate = flightDate;
		this.source = source;
		this.destination = destination;
		this.price = price;
		this.duration = duration;
		this.capacity = capacity;
	}
	public Flight() {
		super();
	}
	
	@Override
	public String toString() {
		return "Flight [flightId=" + flightId + ", flightName=" + flightName + ", date=" + flightDate + ", source=" + source
				+ ", destination=" + destination + ", price=" + price + ", duration=" + duration + ", capacity="
				+ capacity + "]";
	}
	
	
}
