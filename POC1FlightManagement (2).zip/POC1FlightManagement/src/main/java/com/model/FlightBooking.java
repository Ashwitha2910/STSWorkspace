package com.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="FlightBooking")
public class FlightBooking {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int bookingId;
	@ManyToOne
	@JoinColumn(name="custId")
	private Customer customer;
	@ManyToOne
	@JoinColumn(name="flightId")
	private Flight flight;
	private float amount;
	private int seatNo;
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Flight getFlight() {
		return flight;
	}
	public void setFlight(Flight flight) {
		this.flight = flight;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public int getSeatNo() {
		return seatNo;
	}
	public void setSeatNo(int seatNo) {
		this.seatNo = seatNo;
	}
	public FlightBooking(int bookingId, Customer customer, Flight flight, float amount, int seatNo) {
		super();
		this.bookingId = bookingId;
		this.customer = customer;
		this.flight = flight;
		this.amount = amount;
		this.seatNo = seatNo;
	}
	public FlightBooking() {
		super();
	}
	@Override
	public String toString() {
		return "FlightBooking [bookingId=" + bookingId + ", customer=" + customer + ", flight=" + flight + ", amount="
				+ amount + ", seatNo=" + seatNo + "]";
	}
	
	
}
