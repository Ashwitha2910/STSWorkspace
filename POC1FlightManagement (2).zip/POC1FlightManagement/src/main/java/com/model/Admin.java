package com.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Admin")
public class Admin {

	@Id
	private int adminId;
	private String un;
	private String pw;
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	public String getUn() {
		return un;
	}
	public void setUn(String un) {
		this.un = un;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public Admin(int adminId, String un, String pw) {
		super();
		this.adminId = adminId;
		this.un = un;
		this.pw = pw;
	}
	public Admin() {
		super();
	}
	
	
}
