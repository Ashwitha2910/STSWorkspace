package com.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name="Flight")
public class Flight {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int flightId;
	@NotBlank(message="Name Should not be Blank")
	private String flightName;
	@NotBlank(message="Origin Should not be Blank")
	private String origin;
	@NotBlank(message="Destination Should not be Blank")
	private String destination;
	@NotEmpty(message="Please Provide Date")
	private String departureDate;
	@NotEmpty(message="Please Provide Date")
	private String arrivalDate;
	@Min(500)
	private int economyPrice;
//	@NotNull(message="Cannot be 0")
	@Min(1000)
	private int businessPrice;
	public int getFlightId() {
		return flightId;
	}
	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public String getOrigin() {
		return origin;
	}
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getDepartureDate() {
		return departureDate;
	}
	public void setDepartureDate(String departureDate) {
		this.departureDate = departureDate;
	}
	public String getArrivalDate() {
		return arrivalDate;
	}
	public void setArrivalDate(String arrivalDate) {
		this.arrivalDate = arrivalDate;
	}
	public int getEconomyPrice() {
		return economyPrice;
	}
	public void setEconomyPrice(int economyPrice) {
		this.economyPrice = economyPrice;
	}
	public int getBusinessPrice() {
		return businessPrice;
	}
	public void setBusinessPrice(int businessPrice) {
		this.businessPrice = businessPrice;
	}
	public Flight(int flightId, String flightName, String origin, String destination, String departureDate,
			String arrivalDate, int economyPrice, int businessPrice) {
		super();
		this.flightId = flightId;
		this.flightName = flightName;
		this.origin = origin;
		this.destination = destination;
		this.departureDate = departureDate;
		this.arrivalDate = arrivalDate;
		this.economyPrice = economyPrice;
		this.businessPrice = businessPrice;
	}
	public Flight() {
		super();
	}
	
	
}
