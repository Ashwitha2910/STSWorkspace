package com.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.model.Flight;

public interface FlightRepository extends CrudRepository<Flight, Integer>{
	
	public List<Flight> findAllByDepartureDate(String departureDate);
	
//	@Query(value="select * from flight where departureDate=?",nativeQuery=true)
//	public Flight getFlightsByDepartureDate(String departureDate);
	
	@Query(value="select * from flight where origin=? and destination=?",nativeQuery = true)
	public List<Flight> findByOriginAndDestination(String origin,String destination);
}
