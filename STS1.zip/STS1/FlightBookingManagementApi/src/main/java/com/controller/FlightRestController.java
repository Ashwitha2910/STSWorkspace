package com.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.dao.FlightRepository;
import com.model.Flight;

import jakarta.validation.Valid;

@RestController
public class FlightRestController {
	@Autowired
	FlightRepository fRepo;
	
	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping("/flight")
	public Flight addFlight(@RequestBody  @Valid Flight flight) {
		Flight f = new Flight();
		f.setFlightName(flight.getFlightName());
		f.setOrigin(flight.getOrigin());
		f.setDestination(flight.getDestination());
		f.setDepartureDate(flight.getDepartureDate());
		f.setArrivalDate(flight.getArrivalDate());
		f.setEconomyPrice(flight.getEconomyPrice());
		f.setBusinessPrice(flight.getBusinessPrice());
		fRepo.save(f);
		return f;
	}
	
	@PreAuthorize("hasRole('ADMIN')")
	@PutMapping("/flight/{flightId}")
	public Flight updateFlight(@RequestBody Flight flight, @PathVariable("flightId") int flightId) {
		Flight f = new Flight();
		Optional<Flight> fly = fRepo.findById(flightId);
		f = fly.get();
		f.setFlightName(flight.getFlightName());
		f.setOrigin(flight.getOrigin());
		f.setDestination(flight.getDestination());
		f.setDepartureDate(flight.getDepartureDate());
		f.setArrivalDate(flight.getArrivalDate());
		f.setEconomyPrice(flight.getEconomyPrice());
		f.setBusinessPrice(flight.getBusinessPrice());
		fRepo.save(f);
		return f;
	}
	
	@PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping("/flight/{flightId}")
	public Flight deleteFlightById(@PathVariable("flightId") int flightId) {
		Flight f = new Flight();
		f = fRepo.findById(flightId).get();
		fRepo.deleteById(flightId);
		return f;
	}
	
	@GetMapping("/flight")
	public ResponseEntity<List<Flight>> getFlights() {
		List<Flight> list = (List<Flight>) fRepo.findAll();
		return new ResponseEntity<List<Flight>>(list,HttpStatus.OK);
	}
	
	@GetMapping("/flight/{flightId}")
	public Flight getFlightById(@PathVariable("flightId") int flightId) {
		Flight f = new Flight();
		Optional<Flight> fly = fRepo.findById(flightId);
		f = fly.get();
		return f;
	}
	
	@GetMapping("/flight/{origin}/{destination}")
	public List<Flight> getFlightByOriginAndDest(@PathVariable("origin") String origin, @PathVariable("destination") String destination)
	{
//		Flight f=new Flight();
	    List<Flight> fly= (List<Flight>)fRepo.findByOriginAndDestination(origin,destination);
		return fly;
	}
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String,String> handleInvalidArguments(MethodArgumentNotValidException ex){
		Map<String,String> errorMap = new HashMap<>();
		ex.getBindingResult().getFieldErrors().forEach(error->{
			errorMap.put(error.getField(), error.getDefaultMessage());
		});
		return errorMap;
	}
	
	
}
