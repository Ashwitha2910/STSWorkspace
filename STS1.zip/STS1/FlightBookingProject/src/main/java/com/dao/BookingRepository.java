package com.dao;

import org.springframework.data.repository.CrudRepository;

import com.model.BookingDetails;

public interface BookingRepository extends CrudRepository<BookingDetails, Integer>{

}
