package com.dao;

import org.springframework.data.repository.CrudRepository;

import com.model.Customer;

public interface CustomerRepository extends CrudRepository<Customer, Integer>{

}
