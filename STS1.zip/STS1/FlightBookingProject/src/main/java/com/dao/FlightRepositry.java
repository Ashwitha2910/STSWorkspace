package com.dao;

import org.springframework.data.repository.CrudRepository;

import com.model.Flight;

public interface FlightRepositry extends CrudRepository<Flight, Integer>{

}
