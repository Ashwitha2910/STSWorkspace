package com.controller;

public class AdminController {

}
