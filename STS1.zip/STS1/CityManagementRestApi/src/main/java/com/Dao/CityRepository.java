package com.Dao;



import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.model.City;

public interface CityRepository extends CrudRepository<City, Integer>{

	@Query(value= "select * from city  where city_country=?", nativeQuery = true)
	public List<City> findByCountry(String city_country);

}
