package com.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.Dao.CityRepository;
import com.model.City;

@RestController
public class CityController {
	@Autowired
	CityRepository cRepo;
	
	@GetMapping("/city/{city_country}")
	public List<City> getCityDetails(@PathVariable ("city_country") String city_country)
	{
		List<City> list=(List<City>) cRepo.findByCountry(city_country);
		return list;
	}

}
