package com.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="City")
public class City {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int city_id;
	private String city_name;
	private String city_country;
	private String city_desc;

	public int getCity_id() {
		return city_id;
	}

	public void setCity_id(int city_id) {
		this.city_id = city_id;
	}

	public String getCity_name() {
		return city_name;
	}

	public void setCity_name(String city_name) {
		this.city_name = city_name;
	}

	public String getCity_country() {
		return city_country;
	}

	public void setCity_country(String city_country) {
		this.city_country = city_country;
	}

	public String getCity_desc() {
		return city_desc;
	}

	public void setCity_desc(String city_desc) {
		this.city_desc = city_desc;
	}

	public City(int city_id, String city_name, String city_country, String city_desc) {
		super();
		this.city_id = city_id;
		this.city_name = city_name;
		this.city_country = city_country;
		this.city_desc = city_desc;
	}

	public City() {
		super();
	}

}
