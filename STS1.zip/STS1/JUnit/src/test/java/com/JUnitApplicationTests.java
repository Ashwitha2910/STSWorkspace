package com;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JUnitApplicationTests {

	Calculator cal=new Calculator();
	
	@Test
	@Disabled
	void contextLoads() {
	}
	
	@Test
	@DisplayName("Test sum of 3 nos")
	void testDoSum()
	{
		int expectedValue=10;
		int actualOutput=cal.doSum(10, -10, 10);
		assertThat(actualOutput).isEqualTo(expectedValue);
	}
	@Test
	void testDoProduct() {
		int expectedVal=8;
		int actualval=cal.doProduct(2, 2, 2);
		assertThat(actualval).isEqualTo(expectedVal);
	}
	
//	@Test
//	void testDoCompare()
//	{
//		boolean expected=true;
//		boolean actual=cal.isEqual(25, 25);
//		assertThat(actual).isEqualTo(expected);
//	}
	
	@Test
	void testDoCompare()
	{
		boolean actual=cal.isEqual(4, 4);
		assertThat(actual).isTrue();
	}

}
