package com;

public class Calculator {

	public int doSum(int a,int b,int c)
	{
		return a+b+c;
	}
	
	public int doProduct(int a ,int b,int c)
	{
		return a*b*c;
	}
	
	public boolean isEqual(int a,int b)
	{
		return a==b;
	}
}
