package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.model.TaskModel;
import com.repository.TaskRepository;

@RestController
public class TaskController {

	@Autowired
	TaskRepository tRepo;
	
	@GetMapping("/tasks")
	public List<TaskModel> getAllTasks()
	{
		List<TaskModel> li= (List<TaskModel>) tRepo.findAll();
		return li;
	}
	
	@PostMapping("/tasks")
	public ResponseEntity<TaskModel> postTasks(@RequestBody TaskModel taskModel)
	{
		TaskModel tm= new TaskModel();
		tm.setTitle(taskModel.getTitle());
		tm.setDescription(taskModel.getDescription());
		tRepo.save(tm).gettId();
		return new ResponseEntity<TaskModel>(tm,HttpStatus.CREATED);
	}
}
