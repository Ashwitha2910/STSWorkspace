package com.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Task1")
public class TaskModel {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int tId;
	private String title;
	private String description;
	public int gettId() {
		return tId;
	}
	public void settId(int tId) {
		this.tId = tId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public TaskModel(int tId, String title, String description) {
		super();
		this.tId = tId;
		this.title = title;
		this.description = description;
	}
	public TaskModel() {
		super();
	}
	
	
}
