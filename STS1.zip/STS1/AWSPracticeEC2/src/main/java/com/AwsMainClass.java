package com;

import java.util.Arrays;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.AmazonEC2ClientBuilder;
import com.amazonaws.services.ec2.model.AuthorizeSecurityGroupIngressRequest;
import com.amazonaws.services.ec2.model.CreateKeyPairRequest;
import com.amazonaws.services.ec2.model.CreateKeyPairResult;
import com.amazonaws.services.ec2.model.CreateSecurityGroupRequest;
import com.amazonaws.services.ec2.model.CreateSecurityGroupResult;
import com.amazonaws.services.ec2.model.IpPermission;
import com.amazonaws.services.ec2.model.IpRange;
import com.amazonaws.services.ec2.model.RunInstancesRequest;
import com.amazonaws.services.ec2.model.StartInstancesRequest;

public class AwsMainClass {

	public static void main(String[] args) {
		BasicAWSCredentials cred=new BasicAWSCredentials("AKIATPWG3FLKNP2XQOVP", "H0def7ohnUveE3MqKt8dN4Aq5uyIXIZXDB34ZxYu");
		AmazonEC2 ec2= AmazonEC2ClientBuilder.standard().withCredentials(new AWSStaticCredentialsProvider(cred)).withRegion(Regions.US_EAST_1).build();
		
		//Creating Security Groups
		CreateSecurityGroupRequest createSecurityGroupReq=new CreateSecurityGroupRequest().withGroupName("AshwithaSecurityGrp").withDescription("Ashwitha SDK SG");
		CreateSecurityGroupResult createSecurityGrpRes=ec2.createSecurityGroup(createSecurityGroupReq);
		
		//Aallowing HTTP traffic coming from any IP address
		IpRange ipRange=new IpRange().withCidrIp("0.0.0.0/0");
		IpPermission ipPermission=new IpPermission().withIpv4Ranges(Arrays.asList(new IpRange[] {ipRange})).withIpProtocol("tcp").withFromPort(80).withToPort(80);
		
		//Attaching ipRange instance to an security group
		AuthorizeSecurityGroupIngressRequest authorizeecurityGrpIngressReq = new AuthorizeSecurityGroupIngressRequest().withGroupName("AshwithaSecurityGrp")
				.withIpPermissions(ipPermission);
		ec2.authorizeSecurityGroupIngress(authorizeecurityGrpIngressReq);
		
		//Create KeyPair
		CreateKeyPairRequest createKeyPairReq= new CreateKeyPairRequest().withKeyName("assignment-key-pair");
		CreateKeyPairResult createKeyPairRes=ec2.createKeyPair(createKeyPairReq);
		
		//getting private key
		createKeyPairRes.getKeyPair().getKeyMaterial();
		
		//creating ec2 instance
		RunInstancesRequest runInsancesReq=new RunInstancesRequest().withImageId("ami-0c2b0d3fb02824d92").withInstanceType("t2.micro").withKeyName("assignment-key-pair")
				.withMinCount(1).withMaxCount(1).withSecurityGroups("AshwithaSecurityGrp");
		
		//
		String myInstanceId=ec2.runInstances(runInsancesReq).getReservation().getInstances().get(0).getInstanceId();
		
		StartInstancesRequest startInstanceReq=new StartInstancesRequest().withInstanceIds(myInstanceId);
		ec2.startInstances(startInstanceReq);


	}

}
