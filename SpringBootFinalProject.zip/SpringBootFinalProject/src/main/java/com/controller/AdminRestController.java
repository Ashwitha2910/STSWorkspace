package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.dao.AdminRepository;
import com.dao.QuestionRepository;
import com.model.Questions;
import com.model.Student;

@RestController
public class AdminRestController {
	
	@Autowired
	AdminRepository adRepo;
	@Autowired
	QuestionRepository qRepo;

	@PostMapping("/student")
	public Student addStudent(@RequestBody Student student) {
		Student st = new Student();
		st.setFname(student.getFname());
		st.setLname(student.getLname());
		st.setGender(student.getGender());
		st.setAddress(student.getAddress());
		st.setEmail(student.getEmail());
		adRepo.save(st);
		return st;
	}
	
	@ExceptionHandler
	@PutMapping("/student/{stId}")
	public Student updateStudent(@RequestBody Student student, @PathVariable("stId") int stId) {
		Student st = new Student();
		Optional<Student> std =adRepo.findById(stId);
		st = std.get();
		st.setFname(student.getFname());
		st.setLname(student.getLname());
		st.setGender(student.getGender());
		st.setAddress(student.getAddress());
		st.setEmail(student.getEmail());
		adRepo.save(st);
		return st;		
	}
	@ExceptionHandler
	@DeleteMapping("/student/{stId}")
	public Student deleteStudentById(@PathVariable("stId") int stId) {
		Student st = new Student();
		st= adRepo.findById(stId).get();
		adRepo.deleteById(stId);
		return st;		
	}
	
	@GetMapping("/student")
	public List<Student> getStudents(){
	 List<Student> list=(List<Student>) adRepo.findAll();
	 System.out.println(list);
	 return list;
	}
	
	@ExceptionHandler
	@GetMapping("/student/{stId}")
	public Student getStudentById(@PathVariable("stId") int stId) {
		Student st = new Student();
		Optional<Student> std =adRepo.findById(stId);
		st = std.get();
		return st;		
	}
	
	@PostMapping("/question")
	public Questions addQuestion(@RequestBody Questions question) {
		Questions que  = new Questions();
		que.setQue(question.getQue());
		que.setOpt1(question.getOpt1());
		que.setOpt2(question.getOpt2());
		que.setOpt3(question.getOpt3());
		que.setCorrectAns(question.getCorrectAns());
		qRepo.save(que);
		return que;
	}
	
	@ExceptionHandler
	@PutMapping("/question/{qId}")
	public Questions updateQuestion(@RequestBody Questions question, @PathVariable("qId") int qId) {
		Questions q = new Questions();
		Optional<Questions> std =qRepo.findById(qId);
		q = std.get();
		q.setQue(question.getQue());
		q.setOpt1(question.getOpt1());
		q.setOpt2(question.getOpt2());
		q.setOpt3(question.getOpt3());
		qRepo.save(q);
		return q;		
	}
	
	@ExceptionHandler
	@DeleteMapping("/question/{qId}")
	public Questions deleteQuestionById(@PathVariable("qId") int qId) {
		Questions que = new Questions();
		que= qRepo.findById(qId).get();
		qRepo.deleteById(qId);
		return que;		
	}
	
	@GetMapping("/question")
	public List<Questions> getQuestions(){
	 List<Questions> list=(List<Questions>) qRepo.findAll();
	 System.out.println(list);
	 return list;
	}
	
}
