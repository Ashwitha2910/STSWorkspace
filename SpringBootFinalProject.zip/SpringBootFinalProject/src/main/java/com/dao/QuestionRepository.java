package com.dao;

import org.springframework.data.repository.CrudRepository;

import com.model.Questions;

public interface QuestionRepository extends CrudRepository<Questions, Integer>{

}
